<?php
/*------------------------------------------------------------------------
# Payment Fee or Discount
# ------------------------------------------------------------------------
# The Krotek
# Copyright (C) 2011-2016 The Krotek. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Website: http://thekrotek.com
# Support: support@thekrotek.com
-------------------------------------------------------------------------*/

$_['text_payment_fee'] 			= "Payment fee";
$_['text_payment_discount'] 	= "Payment discount";
$_['text_including_fee'] 		= " (including additional fees)";
$_['text_including_discount'] 	= " (including discount)";

?>