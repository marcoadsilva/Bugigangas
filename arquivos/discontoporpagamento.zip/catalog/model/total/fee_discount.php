<?php
/*------------------------------------------------------------------------
# Payment Fee or Discount
# ------------------------------------------------------------------------
# The Krotek
# Copyright (C) 2011-2016 The Krotek. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Website: http://thekrotek.com
# Support: support@thekrotek.com
-------------------------------------------------------------------------*/

if (version_compare(VERSION, '2.2', '<')) {
    class FeeDiscountHelper extends Model
    {
    	public function getTotal(&$total_data, &$total, &$taxes)
    	{		    		
    		$data = array('totals' => &$total_data, 'total' => &$total, 'taxes' => &$taxes);

    		$this->calculateTotal($data);
    	}
    }
} else {
    class FeeDiscountHelper extends Model
    {
    	public function getTotal($data)
    	{		    		
    		$this->calculateTotal($data);
    	}    
    }
}

class ModelTotalFeeDiscount extends FeeDiscountHelper
{
	private $type = "total";
	private $extension = "fee_discount";
	private $path = '';	
		
	public function calculateTotal($data)
	{
		$total_data =& $data['totals'];
		$total =& $data['total'];
		$taxes =& $data['taxes'];
				
		if (!isset($this->session->data['payment_method'])) return;
		
		$this->language->load($this->type.'/'.$this->extension);

		if (version_compare(VERSION, '2.3', '>=')) $this->path = 'extension/';
		 	
		$group = $this->customer->getGroupId();
		$customer_groups = $this->config->get($this->extension.'_customer_groups');
			
		if (!empty($customer_groups) && !in_array($group, $customer_groups)) return;
			
		$subtotal = $this->cart->getSubTotal();
			
		if (!$subtotal) return;
			
 		if (!$total) $total = $subtotal;

		$fees = $this->config->get($this->extension.'_payments');
			
		if (is_array($fees) && isset($fees[$this->session->data['payment_method']['code']])) {
			$dbvalue = $fees[$this->session->data['payment_method']['code']];
			$fee = trim($dbvalue, '%');
		} else {
			$fee = 0;
		}
		
		$fee_min = $this->config->get($this->extension.'_fee_min');
		$discount_min = $this->config->get($this->extension.'_discount_min');
		
		if ((($fee > 0) && (!$fee_min || ($subtotal < $fee_min))) || (($fee < 0) && (!$discount_min || ($subtotal > $discount_min)))) {
			if (strpos($dbvalue, '%') !== false) {
				$value = $total * (trim($dbvalue, '%'))/100;
				$roundby = $this->config->get($this->extension.'_round');
				if ($roundby) $value = ceil($value/$roundby) * $roundby;
			} else {
				$value = $dbvalue;
			}
		
			// Check inactive totals
		
			if ((($value > 0) && $this->config->get($this->extension.'_totals_fee')) || (($value < 0) && $this->config->get($this->extension.'_totals_discount'))) {
				$this->load->model('extension/extension');
				$totals = $this->model_extension_extension->getExtensions('total');
				
				$inactive_data = array();
				$inactive_total = 0;
				$inactive_taxes = $this->cart->getTaxes();
										
				foreach ($totals as $item) {
					if (($item['code'] != $this->extension) && $this->config->get($item['code'].'_status')) {
						$this->load->model($this->path.'total/'.$item['code']);
						$this->{'model_total_'.$item['code']}->getTotal($inactive_data, $inactive_total, $inactive_taxes);
					}
				}
			
				foreach ($inactive_data as $item) {						
					if (($value > 0) && in_array($item['code'], $this->config->get($this->extension.'_totals_fee'))) return;
					elseif (($value < 0) && in_array($item['code'], $this->config->get($this->extension.'_totals_discount'))) return;
				}
			}
			
			// Create title
								
			if ($value > 0) $title = $this->language->get('text_payment_fee');
			else $title = $this->language->get('text_payment_discount');
					
			$add_name = $this->config->get($this->extension.'_add_name');
			$add_value = $this->config->get($this->extension.'_add_value');

			if ($add_name || $add_value) {
				$info = array();
						
				if ($add_name) $info[] = $this->session->data['payment_method']['title'];
				if ($add_value && strpos($dbvalue, '%')) $info[] = $dbvalue;
				
				if ($info) $title .= " (".implode(", ", $info).")";
			}
			
			// Recalculate taxes
			
			if ($this->config->get($this->extension.'_tax_class')) {
				$tax_rates = $this->tax->getRates($value, $this->config->get($this->extension.'_tax_class'));
	
				foreach ($tax_rates as $tax_rate) {
					if (!isset($taxes[$tax_rate['tax_rate_id']])) $taxes[$tax_rate['tax_rate_id']] = $tax_rate['amount'];
					else $taxes[$tax_rate['tax_rate_id']] += $tax_rate['amount'];
				}
			}

			$total += $value;
					
			// Hide total

			if ($this->config->get($this->extension.'_hide_total')) {
				foreach ($total_data as $key => $item) {
					if ($item['code'] == $this->config->get($this->extension.'_add_to')) {
						$newvalue = $item['value'] + $value;
						$total_data[$key]['text'] = $this->formatCurrency($newvalue);
       					$total_data[$key]['value'] = $newvalue;
				 				
				 		if ($this->config->get($this->extension.'_add_info')) {
				 			$total_data[$key]['title'] .= ($value < 0 ? $this->language->get('text_including_discount') : $this->language->get('text_including_fee'));
				 		}
				 		
				 		return;
			 		}
				}
			}
			
			$total_data[] = array(
				'code' => $this->extension,
		     	'title' => $title,
    		    'text' => ($value < 0 ? "-" : "").$this->formatCurrency(abs($value)),
        		'value' => $value,
				'sort_order' => $this->config->get($this->extension.'_sort_order'));
		}
	}
	
	private function formatCurrency($value)
	{
		if (version_compare(VERSION, '2.2', '<')) {
			$value = $this->currency->format($value);
		} else {
			$value = $this->currency->format($value, $this->config->get('config_currency'));
		}
		
		return $value;
	}	
}

?>